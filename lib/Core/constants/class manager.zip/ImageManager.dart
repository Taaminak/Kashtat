class ImageManager {
  static String iconPath = "assets/icons";
  static String imagePath = "assets/images";

  // icons
  static String logo = "$iconPath/Group 26@3x.png";
  static String logoHalfGrey = "$iconPath/Intersection 1@3x.png";
  static String logoWithTitleV = "$iconPath/Group 28@3x.png";
  static String logoWithTitleHWhite = "$iconPath/Group 6332@3x.png";
  static String logoWithTitleHColored = "$iconPath/Group 6332 (2).png";
  static String list = "$iconPath/Action Bar@3x.png";
  static String marker = "$iconPath/akar-iconslocation@3x.png";
  static String linkedIn = "$iconPath/Asset 9@3x.png";
  static String verified = "$iconPath/bipatch-check-fill@3x.png";
  static String backIcon = "$iconPath/Chevron@3x.png";
  static String buildings = "$iconPath/claritybuilding-line@3x.png";
  static String ksaLogo = "$iconPath/Group 6334@3x.png";
  static String camp = "$iconPath/Group 6341@3x.png";
  static String campWithOrangeBg = "$iconPath/Group 6392@3x.png";
  static String markerWithBlueBg = "$iconPath/Group 6390@3x.png";
  static String usersWithGreyBg = "$iconPath/Group 6391@3x.png";
  static String users = "$iconPath/UI icon-group-light@3x.png";
  static String lockWithOrangeBg = "$iconPath/Group 6393@3x.png";
  static String gridList = "$iconPath/ic_view_module_24px@3x.png";
  static String envelopeWithGreenBg = "$iconPath/icon@3x.png";
  static String envelopeWithWhiteBg = "$iconPath/Message@3x.png";
  static String rectangleBgWithMixedColor = "$iconPath/Rectangle 9@3x.png";
  static String finger = "$iconPath/UI icon-hand cursor-light@3x.png";
  static String earth = "$iconPath/UI icon-internet-light@3x.png";
  static String logOut = "$iconPath/UI icon-logout-light@3x.png";
  static String logIn = "$iconPath/UI icon-login-light@3x.png";
  static String messages = "$iconPath/UI icon-messages-light@3x.png";
  static String listV = "$iconPath/UI icon-more_vertical-filled@3x.png";
  static String user = "$iconPath/UI icon-person-light@3x.png";
  static String privacy = "$iconPath/UI icon-shield-light@3x.png";
  static String warning = "$iconPath/UI icon-warning-light@3x.png";
  static String usersBottom = "$iconPath/Vector@3x.png";
  static String aboutUs = "$iconPath/Group 6385@3x.png";
  static String pay = "$iconPath/payment_method_icons/UI icon-payment-light@3x.png";
  static String masterCard = "$iconPath/payment_method_icons/Icon_MasterCard@3x.png";
  static String applePay = "$iconPath/payment_method_icons/Artwork 3@3x.png";
  static String coupon = "$iconPath/payment_method_icons/ic_confirmation_number_24px@3x.png";
  static String cash = "$iconPath/payment_method_icons/Group 951@3x.png";
  static String credit = "$iconPath/payment_method_icons/Icon_Credit Card@3x.png";

  // images
  static String person = "$imagePath/person.jpg";
  static String onBoarding1 = "$imagePath/onboarding1.jpg";
  static String onBoarding2 = "$imagePath/onboarding2.jpg";
  static String onBoarding3 = "$imagePath/onboarding3.jpg";

}